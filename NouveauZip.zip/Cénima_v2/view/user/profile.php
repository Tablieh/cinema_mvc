<?php
    $user = $_SESSION['user'];

    var_dump($user);
?>
