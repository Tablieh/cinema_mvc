
<h1>Cénima</h1>

<main>
                    <aside>
                        <h1>A PROPOS</h1>
                        <div class="lolo">
                            <p>  Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque deserunt sunt fugiat odio, ex voluptates assumenda, in architecto voluptate optio repellat alias doloribus eius dolor earum maiores iusto impedit labore! </p>
                            <p>  omnis totam ullam earum dolorem quod consequuntur!</p>
                            <p>  expedita nobis!</p>
                        </div>
                    </aside>
                    <article class="lolo">
                        <h1> LA PUISSANCE,TOUT SIMPLEMENT.</h1>

                        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam, placeat consectetur illum dolores eaque nesciunt voluptate sapiente vero reiciendis velit earum nobis dolor commodi rem perspiciatis corrupti quia repellat reprehenderit. Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima recusandae repellat consequuntur earum quam voluptates error sequi voluptatem iure ducimus!</p>
                        <p> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ullam officiis, fuga dolorum itaque aliquid iusto, assumenda asperiores a error et natus aperiam, voluptatibus laborum molestias vitae. Minima, eveniet repellat? Totam?</p>
                        <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit quam, quis, cumque quibusdam eveniet, deleniti vel dolores laudantium dolor assumenda exercitationem inventore magni nisi magnam enim placeat incidunt voluptatum consectetur!</p>
                    </article>
                </main>
                <footer>
            
                    <section >
                        <h1>NEWSLETTER</h1>
                        <input type="name" placeholder="Name"></br>
                        <input type="email" placeholder="Email">
                        <input id="submit" type="submit" value="S'inscrire">
                    </section>
                    <div id="Social">
                            <i class="fab fa-facebook-f"></i>
                            <i class="fab fa-twitter"></i>
                            <i class="fab fa-instagram"></i>
                            <i class="fab fa-snapchat"></i>
                            <i class="fab fa-linkedin"></i>
                    </div>
                </footer>

